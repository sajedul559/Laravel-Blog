

<!-- copyright -->
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <p>Copyrights &copy; 2021 - <a target="_blank" href="http://sajedulcu43.ezyro.com/">Sajedul Islam</a>,  All Rights Reserved.</p>
            </div>
            <div class="col-lg-6 text-right col-md-12">
                <div class="social-icons">
                    <ul>
                        <li><a href="https://www.facebook.com/sajedul559" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="https://www.github.com/sajedul559" target="_blank"><i class="fab fa-github"></i></a></li>
                        <li><a href="https://www.linkedin.com/sajedul559"  target="_blank"><i class="fab fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end copyright -->
