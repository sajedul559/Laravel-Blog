
<?php $__env->startSection('title','Save Post'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-10 mb-5 ml-5">
				<h3>Edit Post</h3>
				<div class="table-responsive">

                <?php if($errors): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-danger"><?php echo e($error); ?></p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(Session::has('success')): ?>
                <p class="text-success"><?php echo e(session('success')); ?></p>
                <?php endif; ?>

                <form method="post" action="<?php echo e(url('update-post/'.$post->id)); ?>"  enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <table class="table table-bordered">
                    <tr>
                          <th>Category<span class="text-danger">*</span></th>
                          <td>
                            <select class="form-control" name="category">
                              <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cat->id==$post->cat_id): ?>
                                <option selected value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>
                    </tr>
                    <tr>
                        <th>Title</th>
                        <td><input type="text" value="<?php echo e($post->title); ?>" name="title" class="form-control" /></td>
                    </tr>
                    <tr>
                        <th>Thumb</th>
                        <td>
                          <p class="my-2"><img width="80" src="<?php echo e(asset('imgs/thumb')); ?>/<?php echo e($post->thumb); ?>" /></p>
                          <input type="hidden" value="<?php echo e($post->thumb); ?>" name="post_thumb" />
                          <input type="file" name="post_thumb" />
                        </td>
                    </tr>
                    <tr>
                        <th>Full Image</th>
                        <td>
                          <p class="my-2"><img width="80" src="<?php echo e(asset('imgs/full')); ?>/<?php echo e($post->full_img); ?>" /></p>
                          <input type="hidden" value="<?php echo e($post->full_img); ?>" name="post_image" />
                          <input type="file" name="post_image" />
                        </td>
                    </tr>
                    <tr>
                        <th>Detail<span class="text-danger">*</span></th>
                        <td>
                          <textarea class="form-control" id="summary" name="detail"><?php echo e($post->detail); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>Tags</th>
                        <td>
                          <textarea class="form-control" name="tags"><?php echo e($post->tags); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" >
                            <button  type="submit" class="btn btn-success col-md-12">Update</button>
                        </td>
                    </tr>
                </table>
                </form>
              </div>
			</div>
           
		</div>
<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>


<script type="text/javascript">
   
      $(document).ready(function() {
        $('#summary').summernote();
      });
</script>
        
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/edit_post.blade.php ENDPATH**/ ?>