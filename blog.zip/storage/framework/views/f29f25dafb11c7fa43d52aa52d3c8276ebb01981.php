<?php $__env->startSection('title','Manage Posts'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row" style="padding-top:50px;">
			<div class="col-md-8 mb-5">
						<?php if(Session::has('success')): ?>
							<p class="text-success"><?php echo e(session('success')); ?></p>
						<?php endif; ?>
						<h3 class="mb-4">Manage Posts</h3>
					<div class="table-responsive">
							<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
									<th>#</th>
									<th>Category</th>
									<th>Title</th>
									<th>Image</th>
									<th>Full</th>
									<th>Action</th>

									</tr>
								</thead>
								<tfoot>
									<tr>
									<th>#</th>
									<th>Category</th>
									<th>Title</th>
									<th>Image</th>
									<th>Full</th>
									</tr>
								</tfoot>
								<tbody>
									<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($post->id); ?></td>
										<td><?php echo e($post->category->title); ?></td>
										<td><?php echo e($post->title); ?></td>
										<td><img src="<?php echo e(asset('imgs/thumb').'/'.$post->thumb); ?>" width="100" /></td>
										<td><img src="<?php echo e(asset('imgs/full').'/'.$post->full_img); ?>" width="100" /></td>
										<td>
											<a class="btn btn-info btn-sm" href="<?php echo e(route('editPost',$post->id)); ?>"><span class="fa fa-pencil"></span></a>
											<a onclick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-sm" href="<?php echo e(route('deletePost',$post->id)); ?>"><span class="fa fa-trash"></span></a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
					</div>
			</div>
			<!-- Right SIdebar -->
			<div class="col-md-4 pt-5">
				<!-- Search -->
				
				<!-- Recent Posts -->
				<div class="card mb-4">
					<h5 class="card-header">Recent Posts</h5>
					<div class="list-group list-group-flush">
						<?php if($recent_posts): ?>
							<?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(route('single.post',$post->id)); ?>" class="list-group-item"><?php echo e($post->title); ?></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
				<!-- Popular Posts -->
				<div class="card mb-4">
					<h5 class="card-header">Popular Posts</h5>
					<div class="list-group list-group-flush">
						<?php if($popular_posts): ?>
						<?php $__currentLoopData = $popular_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					     	<a href="<?php echo e(route('single.post',$post->id)); ?>" class="list-group-item float-left"><?php echo e($post->title); ?> <span class="badge badge-success float-right"><?php echo e($post->views); ?></span></a> 
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
<!-- Page level plugin CSS-->
<link href="<?php echo e(asset('backend')); ?>/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/dataTables.bootstrap4.js"></script>
<script src="<?php echo e(asset('backend')); ?>/js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>


<script type="text/javascript">
   
      $(document).ready(function() {
        $('#summary').summernote();
      });
</script>
        
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/manage-posts.blade.php ENDPATH**/ ?>