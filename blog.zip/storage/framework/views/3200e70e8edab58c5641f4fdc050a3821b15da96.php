<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title>Single Post</title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('frontend/assets/img/favicon.png')); ?>">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"  crossorigin="anonymous"/>

	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/all.min.css')); ?>">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/bootstrap/css/bootstrap.min.css')); ?>">
	<!-- owl carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/owl.carousel.css')); ?>">
	<!-- magnific popup -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.css')); ?>">
	<!-- animate css -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.css')); ?>">
	<!-- mean menu css -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/meanmenu.min.css')); ?>">
	<!-- main style -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/main.css')); ?>">
	<!-- responsive -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">

</head>
<body>
	
	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="assets/img/logo.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu text-right">
							<ul>
                                <?php if(auth()->guard()->check()): ?>
                                <li class="current-list-item"><a href="<?php echo e(route('home')); ?>">Home</a>
									
								</li>
								<li>
									<a href="<?php echo e(url('save-post-form')); ?>">Add Post</a>
								</li>
								<li>
									<a href="<?php echo e(url('manage-posts')); ?>">Manage Posts</a>
								</li>
								<li>
									<a href="<?php echo e(url('all-categories')); ?>">Categories</a>
								</li>
									
								</li>

								<li>
									<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
									document.getElementById('logout-form').submit();">Logout</a>
									 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
										<?php echo csrf_field(); ?>
									</form>
								</li>
                               
								
                                <?php endif; ?>

                                <?php if(auth()->guard()->guest()): ?>
                                <li class="current-list-item"><a href="<?php echo e(route('home')); ?>">Home</a>
									
								</li>
								<li><a href="about.html">About</a></li>
									
								</li>
									
								</li>
								<li><a href="contact.html">Contact</a></li>
								<li><a href="shop.html">Shop</a>
									
								</li>
                                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                <?php endif; ?>
                               
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->

	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
							<input type="text" placeholder="Keywords">
							<button type="submit">Search <i class="fas fa-search"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search arewa -->
	
	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="breadcrumb-text">
						<p>Read the Details</p>
						<h1>Single Article</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end breadcrumb section -->
	
	<!-- single article section -->
	<div class="mt-150 mb-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 ">
                    <?php if(Session::has('success')): ?>
					  <p class="text-success"><?php echo e(session('success')); ?></p>
				    <?php endif; ?>
                    <h5 class="card-header">
						<?php echo e($post->title); ?>

					<div class="float-right"><span class="  badge badge-success"><?php echo e($post->views); ?> </span>  <span class=" fa fa-eye"> </span></div>
					</h5>
					<div class="single-article-section">
						<div class="single-article-text">
							<div  class="single-artcile-bg mb-5"><img src="<?php echo e(asset('imgs/full/'.$post->full_img)); ?>" alt="" ></div>
							<p class="blog-meta">
								<?php if($post->user): ?>
								<span class="author"><i class="fas fa-user"></i><?php echo e($post->user->name); ?></span>

								<?php else: ?>
								<span class="author"><i class="fas fa-user"></i>Admin</span>

								<?php endif; ?>
								<span class="date"><i class="fas fa-calendar"></i><?php echo e($post->created_at->diffForHumans()); ?></span>
							</p>
							<h2><?php echo $post->title; ?></h2>
                            <p><?php echo $post->detail; ?></p>
							
						</div>
                        <div style="margin-right: -400px;">
                            <div class="comments-list-wrap ">
                                
                                <h5 class="card-header text-center">Total Comments: <span class="badge badge-dark"><?php echo e(count($post->comments)); ?></span></h5>
    
                                <div class="comment-list">
                                    <div class="single-comment-body">
                                        <div class="comment-user-avater">
                                            <img src="assets/img/avaters/avatar1.png" alt="">
                                        </div>
                                        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="comment-text-body">
                                                <h4><?php echo e($comment->user->name); ?><span class="comment-date"><?php echo e($comment->created_at->diffForHumans()); ?></span> <a href="#">reply</a></h4>
                                                <p class=" "><?php echo e($comment->comment); ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                    </div>
                                    
                                </div>
                            </div>
    
                            <?php if(auth()->guard()->check()): ?>
                                <div class="comment-template ">
                                    <h4>Leave a comment</h4>
                                    <p>If you have a comment dont feel hesitate to send us your opinion.</p>
                                    <form method="post" action="<?php echo e(url('save-comment/'.Str::slug($post->title).'/'.$post->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        
                                        <p><textarea name="comment" id="comment" cols="30" rows="10" placeholder="Your Message"></textarea></p>
                                        <p><input type="submit" value="Submit"></p>
                                    </form>
                                </div>
                                
                            <?php endif; ?>

                        </div>

						

						
					</div>
				</div>
				<div class="col-lg-4">
					<div class="sidebar-section">
						<div class="recent-posts">
							<h4>Recent Posts</h4>
							<ul>
                                <?php $__currentLoopData = $recent_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><a href="<?php echo e(route('single.post',$recent->id)); ?>"><?php echo e($recent->title); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</ul>
						</div>
						<div class="archive-posts">
							<h4>Popular Posts</h4>
							<ul>
                                <?php $__currentLoopData = $popular_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a  href="<?php echo e(route('single.post',$popular->id)); ?>"><?php echo e($popular->title); ?></a> <span class="badge badge-success float-right"><?php echo e($popular->views); ?></span></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</ul>
						</div>
						<div class="tag-section">
							<h4>Previous Post</h4>
							<ul>
								<?php if($previous_post): ?>
                                <a href="<?php echo e(route('single.post',$previous_post->id)); ?>">
                                    <span>Previous</span><?php echo e($previous_post->title); ?>

                                </a>
                                    
                                <?php endif; ?>
								
							</ul>
                            <h4>Next Post</h4>
							<ul>
								<?php if($next_post): ?>
                                <a href="<?php echo e(route('single.post',$next_post->id)); ?>">
                                    <span>Next</span><?php echo e($next_post->title); ?>

                                </a>
                                    
                                <?php endif; ?>
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end single article section -->

	
	<!-- copyright -->
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <p>Copyrights &copy; 2021 - <a target="_blank" href="http://sajedulcu43.ezyro.com/">Sajedul Islam</a>,  All Rights Reserved.</p>
            </div>
            <div class="col-lg-6 text-right col-md-12">
                <div class="social-icons">
                    <ul>
                        <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-dribbble"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end copyright -->


	
<script src="<?php echo e(asset('frontend/assets/js/jquery-1.11.3.min.js')); ?>"></script>
<!-- bootstrap -->
<script src="<?php echo e(asset('frontend/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- count down -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.countdown.js')); ?>"></script>
<!-- isotope -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.isotope-3.0.6.min.js')); ?>"></script>
<!-- waypoints -->
<script src="<?php echo e(asset('frontend/assets/js/waypoints.js')); ?>"></script>
<!-- owl carousel -->
<script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>
<!-- magnific popup -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- mean menu -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.meanmenu.min.js')); ?>"></script>
<!-- sticker js -->
<script src="<?php echo e(asset('frontend/assets/js/sticker.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>

</body>
</html><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/frontend/post/single.blade.php ENDPATH**/ ?>