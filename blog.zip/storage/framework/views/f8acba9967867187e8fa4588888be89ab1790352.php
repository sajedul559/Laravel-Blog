<?php $__env->startSection('content'); ?>
<div class="container-fluid">

  <!-- Breadcrumbs-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">
      <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Overview</li>
  </ol>


  <!-- DataTables Example -->
  <div class="card mb-3">
    <div class="card-header">
      <i class="fas fa-table"></i> Update Post
      <a href="<?php echo e(url('admin/post')); ?>" class="float-right btn btn-sm btn-dark">All Data</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">

        <?php if($errors): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
        <p class="text-success"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url('admin/post/'.$data->id)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <table class="table table-bordered">
              <tr>
                    <th>Category<span class="text-danger">*</span></th>
                    <td>
                      <select class="form-control" name="category">
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($cat->id==$data->cat_id): ?>
                          <option selected value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </td>
              </tr>
              <tr>
                  <th>Title</th>
                  <td><input type="text" value="<?php echo e($data->title); ?>" name="title" class="form-control" /></td>
              </tr>
              <tr>
                  <th>Thumb</th>
                  <td>
                    <p class="my-2"><img width="80" src="<?php echo e(asset('imgs/thumb')); ?>/<?php echo e($data->thumb); ?>" /></p>
                    <input type="hidden" value="<?php echo e($data->thumb); ?>" name="post_thumb" />
                    <input type="file" name="post_thumb" />
                  </td>
              </tr>
              <tr>
                  <th>Full Image</th>
                  <td>
                    <p class="my-2"><img width="80" src="<?php echo e(asset('imgs/full')); ?>/<?php echo e($data->full_img); ?>" /></p>
                    <input type="hidden" value="<?php echo e($data->full_img); ?>" name="post_image" />
                    <input type="file" name="post_image" />
                  </td>
              </tr>
              <tr>
                  <th>Detail<span class="text-danger">*</span></th>
                  <td>
                    <textarea class="form-control" name="detail"><?php echo e($data->detail); ?></textarea>
                  </td>
              </tr>
              <tr>
                  <th>Tags</th>
                  <td>
                    <textarea class="form-control" name="tags"><?php echo e($data->tags); ?></textarea>
                  </td>
              </tr>
              <tr>
                  <td colspan="2">
                      <input type="submit" class="btn btn-primary" />
                  </td>
              </tr>
          </table>
        </form>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/backend/post/update.blade.php ENDPATH**/ ?>