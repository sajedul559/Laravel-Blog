<?php $__env->startSection('content'); ?>
<div class="container-fluid">

  <!-- Breadcrumbs-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">
      <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Overview</li>
  </ol>


  <!-- DataTables Example -->
  <div class="card mb-3">
    <div class="card-header">
      <i class="fas fa-table"></i> Add Category
      <a href="<?php echo e(url('admin/category')); ?>" class="float-right btn btn-sm btn-dark">All Data</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">

        <?php if($errors): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
        <p class="text-success"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url('admin/category/'.$data->id)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <table class="table table-bordered">
              <tr>
                  <th>Title</th>
                  <td><input type="text" value="<?php echo e($data->title); ?>" name="title" class="form-control" /></td>
              </tr>
              <tr>
                  <th>Detail</th>
                  <td><input type="text" value="<?php echo e($data->title); ?>" name="detail" class="form-control" /></td>
              </tr>
              <tr>
                  <th>Image</th>
                  <td>
                    <p class="my-2"><img width="80" src="<?php echo e(asset('imgs')); ?>/<?php echo e($data->image); ?>" /></p>
                    <input type="hidden" value="<?php echo e($data->image); ?>" name="cat_image" />
                    <input type="file" name="cat_image" />
                  </td>
              </tr>
              <tr>
                  <td colspan="2">
                      <input type="submit" class="btn btn-primary" />
                  </td>
              </tr>
          </table>
        </form>
      </div>
    </div>
    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
  </div>

</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/backend/category/update.blade.php ENDPATH**/ ?>