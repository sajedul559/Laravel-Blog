<?php $__env->startSection('title','Manage Posts'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-8 mb-5">
				<h3 class="mb-4">Manage Posts</h3>
				<div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th>Category</th>
              <th>Title</th>
              <th>Image</th>
              <th>Full</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>#</th>
              <th>Category</th>
              <th>Title</th>
              <th>Image</th>
              <th>Full</th>
            </tr>
          </tfoot>
          <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->category->title); ?></td>
                <td><?php echo e($post->title); ?></td>
                <td><img src="<?php echo e(asset('imgs/thumb').'/'.$post->thumb); ?>" width="100" /></td>
                <td><img src="<?php echo e(asset('imgs/full').'/'.$post->full_img); ?>" width="100" /></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        </div>
			</div>
			<!-- Right SIdebar -->
			<div class="col-md-4">
				<!-- Search -->
				<div class="card mb-4">
					<h5 class="card-header">Search</h5>
					<div class="card-body">
						<form action="<?php echo e(url('/')); ?>">
							<div class="input-group">
							  <input type="text" name="q" class="form-control" />
							  <div class="input-group-append">
							    <button class="btn btn-dark" type="button" id="button-addon2">Search</button>
							  </div>
							</div>
						</form>
					</div>
				</div>
				<!-- Recent Posts -->
				<div class="card mb-4">
					<h5 class="card-header">Recent Posts</h5>
					<div class="list-group list-group-flush">
						<?php if($recent_posts): ?>
							<?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="#" class="list-group-item"><?php echo e($post->title); ?></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
				<!-- Popular Posts -->
				<div class="card mb-4">
					<h5 class="card-header">Popular Posts</h5>
					<div class="list-group list-group-flush">
						<a href="#" class="list-group-item">Post 1</a>
						<a href="#" class="list-group-item">Post 2</a>
					</div>
				</div>
			</div>
		</div>
<!-- Page level plugin CSS-->
<link href="<?php echo e(asset('backend')); ?>/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('backend')); ?>/vendor/datatables/dataTables.bootstrap4.js"></script>
<script src="<?php echo e(asset('backend')); ?>/js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel-8-blog-website-master\resources\views/manage-posts.blade.php ENDPATH**/ ?>