	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-right">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="assets/img/logo.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
                                <?php if(auth()->guard()->check()): ?>
                                <li class="current-list-item"><a  href="<?php echo e(url('/')); ?>">Home</a>
									
								</li>
								<li>
									<a href="<?php echo e(url('all-categories')); ?>">Categories</a>
								</li>

								<li>
									<a href="<?php echo e(url('save-post-form')); ?>">Add Post</a>
								</li>
								<li>
									<a href="<?php echo e(url('manage-posts')); ?>">Manage Posts</a>
								</li>
								<li>
									<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
									document.getElementById('logout-form').submit();">Logout</a>
									 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
										<?php echo csrf_field(); ?>
									</form>
								</li>

								
                                <?php endif; ?>

                                <?php if(auth()->guard()->guest()): ?>
                                <li class="current-list-item"><a href="#">Home</a>
									
								</li>
								<li>
									<a href="<?php echo e(url('all-categories')); ?>">Categories</a>
								</li>
									
								</li>
									
								</li>
									
								</li>
                                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
								
                                <?php endif; ?>
                               
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->
	<?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>