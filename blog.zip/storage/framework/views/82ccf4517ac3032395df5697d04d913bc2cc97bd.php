<!-- jquery -->
<script src="<?php echo e(asset('frontend/assets/js/jquery-1.11.3.min.js')); ?>"></script>
<!-- bootstrap -->
<script src="<?php echo e(asset('frontend/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- count down -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.countdown.js')); ?>"></script>
<!-- isotope -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.isotope-3.0.6.min.js')); ?>"></script>
<!-- waypoints -->
<script src="<?php echo e(asset('frontend/assets/js/waypoints.js')); ?>"></script>
<!-- owl carousel -->
<script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>
<!-- magnific popup -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- mean menu -->
<script src="<?php echo e(asset('frontend/assets/js/jquery.meanmenu.min.js')); ?>"></script>
<!-- sticker js -->
<script src="<?php echo e(asset('frontend/assets/js/sticker.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>

<?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/frontend/layouts/scripts.blade.php ENDPATH**/ ?>