

<?php $__env->startSection('main_content'); ?>
<div class="latest-news " style="background: black">
    <marquee  behavior="" direction="">Global education calls for effective leadership and coordination now more than ever <strong class="text-warning">***</strong>Early moments matter in co-parenting: A letter from a new mother to her son<strong class="text-warning">***</strong>Time to care – supporting parents and families through family-friendly policies<strong class="text-warning">***</strong></marquee>

</div>

<div class="latest-news pt-50 pb-150">

    <div class="container">

        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-center">
                <div class="section-title">	
                    <h3><span class="orange-text">Features</span> News</h3>
                    <p></p>
                </div>
            </div>
        </div>

        <div class="row">
        
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="single-latest-news">
                    <a  href="<?php echo e(route('single.post',$post->id)); ?>"><div class="latest-news-bg news-bg-1 mb-5 "><img src="<?php echo e(asset('imgs/full/'.$post->full_img)); ?>" alt="" height="250" width="360" style="margin-bottom: 100px;"></div></a>
                    <div class="news-text-box">
                        <h3><a  href="<?php echo e(route('single.post',$post->id)); ?>"><?php echo Str::limit("$post->title", 25); ?></a></h3>
                        <p class="blog-meta">
                         <?php if($post->user): ?>
                         <span class="author"><i class="fas fa-user"><?php echo e($post->user->name); ?></i></span>
                         <?php else: ?>
                         <span class="author"><i class="fas fa-user">Admin</i></span>

                         <?php endif; ?>
                  
                            <span class="date"><i class="fas fa-calendar"></i> <?php echo e($post->created_at->diffForHumans()); ?></span>
                        </p>
                        <p class="excerpt"> <?php echo Str::limit("$post->detail", 240); ?>


                        </p>
                        <a  href="<?php echo e(route('single.post',$post->id)); ?>" class="read-more-btn">read more <i class="fas fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/frontend/home.blade.php ENDPATH**/ ?>