<?php $__env->startSection('content'); ?>
        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>


          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i> Manage Settings
            </div>
            <div class="card-body">
              <div class="table-responsive">

                <?php if($errors): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-danger"><?php echo e($error); ?></p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(Session::has('success')): ?>
                <p class="text-success"><?php echo e(session('success')); ?></p>
                <?php endif; ?>

                <form method="post" action="<?php echo e(url('admin/setting')); ?>" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <table class="table table-bordered">
                      <tr>
                          <th>Comment Auto Approve</th>
                          <td><input <?php if($setting): ?> value="<?php echo e($setting->comment_auto); ?>" <?php endif; ?> type="text" name="comment_auto" class="form-control" /></td>
                      </tr>
                      <tr>
                          <th>User Auto Approve</th>
                          <td><input <?php if($setting): ?> value="<?php echo e($setting->user_auto); ?>" <?php endif; ?> type="text" name="user_auto" class="form-control" /></td>
                      </tr>
                      <tr>
                          <th>Recent Post Limit</th>
                          <td><input <?php if($setting): ?> value="<?php echo e($setting->recent_limit); ?>" <?php endif; ?> type="text" name="recent_limit" class="form-control" /></td>
                      </tr>
                      <tr>
                          <th>Popular Post Limit</th>
                          <td><input <?php if($setting): ?> value="<?php echo e($setting->popular_limit); ?>" <?php endif; ?> type="text" name="popular_limit" class="form-control" /></td>
                      </tr>
                      <tr>
                          <th>Recent Comments Limit</th>
                          <td><input <?php if($setting): ?> value="<?php echo e($setting->recent_comment_limit); ?>" <?php endif; ?> type="text" name="recent_comment_limit" class="form-control" /></td>
                      </tr>
                      <tr>
                          <td colspan="2">
                              <input type="submit" class="btn btn-primary" />
                          </td>
                      </tr>
                  </table>
                </form>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel-8-blog-website-master\resources\views/backend/setting/index.blade.php ENDPATH**/ ?>