<?php $__env->startSection('title',$category->title); ?>
<?php $__env->startSection('content'); ?>
		<div class="row" style="padding-top:60px;">
			<div class="col-md-12">
				<div class="section-title">	
					<?php if($posts): ?>
					<h3 class="text-center"><span class="orange-text"><?php echo e($category->title); ?> </span> Category Post</h3>

					<?php endif; ?>
                </div>
				<div class="row mb-5"> 
					<?php if(count($posts)>0): ?>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4">
							<div class="card">
							  <a  href="<?php echo e(route('single.post',$post->id)); ?>" ><img src="<?php echo e(asset('imgs/full/'.$post->full_img)); ?>" height="250" width="360"  class="card-img-top" alt="<?php echo e($post->title); ?>" /></a>
							  <div class="card-body">
							    <h5 class="card-title"><a href="<?php echo e(route('single.post',$post->id)); ?>" ><?php echo e($post->title); ?></a></h5>
							  </div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<p class="alert alert-danger">No Post Found</p>
					<?php endif; ?>
				</div>
				<!-- Pagination -->
				
			</div>
			
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_blog\resources\views/category.blade.php ENDPATH**/ ?>